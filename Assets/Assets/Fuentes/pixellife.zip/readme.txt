...

PUNKROCKTYPOGRAPHY.typeface

Copyright: 1998-2000 william.clifford

Website: http://www.williac.com


License: You, the user, are permitted to use this typeface for your
design/word processing purposes. You may use it for both private and
commercial causes. You may redistribute this typeface only if you
include this file (readme.txt) with it.

This typeface does not have a complete character set.

You use this typeface at your own risk.

If you like this typeface, please tell me.

If you would like to remix this typeface, please give me credit.

I own this typeface. It is my property. I am letting you use it.

My email address is punkrock@williac.com

...
